#include <stdio.h>

void inc(int a){
  a=a+1;
  printf("a=%d\n",a);
}

void inc_v2(int* a){
  *a=*a+1;
}

int main(void) {
  int x=10;
  inc(x);
  //inc_v2(&x);
  printf("x=%d\n",x);

  return 0;
}
#include <stdio.h>

int main(void) {
  int a[3]={10,11,12};
  int* p=a;

  printf("a[0]=%d\n",a[0]);
  printf("a[1]=%d\n",a[1]);
  printf("a[2]=%d\n",a[2]);
  printf("a=%p\n",a);
  printf("%d\n",*a);
  printf("%d\n", *(a+1));

  printf("p=%p\n",p);
  printf("x=%p\n",a);

}
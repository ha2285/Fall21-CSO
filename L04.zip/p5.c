#include <stdio.h>

int main(void) {
  int b[2][3]={{1,2,3},{4,5,6}};
  //int(*p)[3]=a;
  printf("b=%p\n", b);
  printf("b[0]=%p\n", b[0]);
  //printf("%p\n", p);
  printf("%d\n", *(*b));
  printf("%d\n", *b[0]);
}
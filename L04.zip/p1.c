#include <stdio.h>
#include <string.h>
struct person{
  int id;
  char name[10];
};
int main(void) {
  struct person p1;
  p1.id=10;
  strcpy(p1.name,"james");
  printf("%d\n",p1.id);
  printf("%s\n",p1.name);
  return 0;
}
#include<stdio.h>
#include<string.h>
typedef struct person{
    char name[10];
    int id;
}PERSON;

int main(){
    PERSON p;
    FILE* fptr=fopen("structdata.dat","rb");
    fread(&p, sizeof(p),1,fptr);
    printf("Name= %s, id=%d\n",p.name,p.id);
    fread(&p, sizeof(p),1,fptr);
    printf("Name= %s, id=%d\n",p.name,p.id);
    fclose(fptr);
}
#include <stdio.h>
int main(){
    FILE* fptr;
    fptr=fopen("data.txt","r");
    if (fptr==NULL){
        printf("Unable to open the file");
    }else{
        // we were able to open the file
        //Option -1: using fgetc(fptr)
        /*
        char ch;
        while((ch=fgetc(fptr))!=EOF){
            printf("%c",ch);
        }
        */

       // Option-2: using fscanf()
       //char s[10];
       //fscanf(fptr,"%s",s);
       //printf("%s\n",s);
       //int x;
       //fscanf(fptr,"%d",&x);
       //printf("%d\n",x);
       /*
       while(!feof(fptr)){
            fscanf(fptr,"%s",s);
            printf("%s\n",s);
       }
       */

      //Option-3: using fgets
      char s[100];
      while(fgets(s,100,fptr)!=NULL){
          printf("%s",s);
      }

      fclose(fptr);
    }
}
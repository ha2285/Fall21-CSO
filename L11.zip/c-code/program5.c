#include<stdio.h>
#include<string.h>
typedef struct person{
    char name[10];
    int id;
}PERSON;

int main(){
    PERSON p1, p2;
    p1.id=10;
    strcpy(p1.name,"james");
    p2.id=11;
    strcpy(p2.name,"alma");
    FILE* fptr=fopen("structdata.dat","wb");
    fwrite(&p1,sizeof(PERSON),1,fptr);
    fwrite(&p2,sizeof(PERSON),1,fptr);
    fclose(fptr);
}
#include<stdio.h>
int main(){
    FILE* fptr=fopen("binarydata.dat","rb");
    if (fptr==NULL){
        return 0;
    }else{
        int x;
        /*
        fread(&x, sizeof(int),1, fptr);
        printf("%d\n",x);
        fread(&x, sizeof(int),1, fptr);
        printf("%d\n",x);
        printf("%ld\n",ftell(fptr));
        fseek(fptr, -4, SEEK_CUR);
        fread(&x, sizeof(int),1, fptr);
        printf("%d\n",x);
        fclose(fptr);
        */
       fseek(fptr,0,SEEK_END);
       int num_of_values=ftell(fptr)/sizeof(int);
       printf("Number of values in the file is: %d\n",num_of_values);
    }
    
}
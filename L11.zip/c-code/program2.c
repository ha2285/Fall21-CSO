#include<stdio.h>
int main(){
    FILE* fptr=fopen("mydata.txt","a");
    //Option-1: using putc
    //putc('a',fptr);
    //putc('b',fptr);
    //putc('c',fptr);
    //fclose(fptr);

    //Option-2: fprintf()
    fprintf(fptr,"%s","hello");
    fclose(fptr);
}
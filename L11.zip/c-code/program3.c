#include<stdio.h>
int main(){
    // as text file
    //FILE* fptr1=fopen("textdata.txt","w");
    //fprintf(fptr1,"%s","-12345");
    //fclose(fptr1);

    // as binary
    FILE* fptr2=fopen("binarydata.dat","wb");
    int x[3]={100,200,300};
    fwrite(&x, sizeof(int), 3, fptr2);
    fclose(fptr2);

}